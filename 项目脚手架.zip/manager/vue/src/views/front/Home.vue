<template>
  <div class="main-content">

  </div>
</template>

<script>

export default {

  data() {
    return {

    }
  },
  mounted() {

  },
  // methods：本页面所有的点击事件或者其他函数定义区
  methods: {

  }
}
</script>
